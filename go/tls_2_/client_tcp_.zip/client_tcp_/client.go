// client.go

package main

import (
	"crypto/tls"
	"flag"
	"io"
	"log"
)

//------------------------------------------------------------------------------

const BUFFER_SIZE = 64

const CLIENT_HOST_DEFAULT = "localhost"
const CLIENT_PATH_DEFAULT = "/"
const CLIENT_PORT_DEFAULT = "443"
const CLIENT_PROTOCOL = "https://"
const CLIENT_PROTOCOL_METHOD = "GET"
const CLIENT_PROTOCOL_VERSION_FULL = "HTTP/1.1"

const NL = "\r\n"

//------------------------------------------------------------------------------

var cla_host *string
var cla_path *string
var cla_port *string

var client_connection_host string
var client_connection_path string
var client_connection_port string
var client_connection_type string
var client_connection_address string

var request_str string
var request_uri string

var tls_config *tls.Config
var tls_connection *tls.Conn

//------------------------------------------------------------------------------

func main() {

	var buffer []byte // Connection Buffer.
	var data []byte   // Actual Data from Buffer.
	var err error
	var n int
	var servers_reply []byte

	// Preparations.
	buffer = make([]byte, BUFFER_SIZE)

	// Command Line Arguments.
	cla_host = flag.String("host", CLIENT_HOST_DEFAULT, "Host Name.")
	cla_port = flag.String("port", CLIENT_PORT_DEFAULT, "Port Number.")
	cla_path = flag.String("path", CLIENT_PATH_DEFAULT, "Resource Path.")
	flag.Parse()
	client_connection_host = *cla_host
	client_connection_port = *cla_port
	client_connection_path = *cla_path

	// Settings.
	log.SetFlags(log.Lshortfile)
	client_connection_type = "tcp"
	tls_config = &tls.Config{

		ServerName:         client_connection_host,
		InsecureSkipVerify: true,
	}

	// Client's Address.
	client_connection_address =
		client_connection_host + ":" + client_connection_port

	// Connect.
	tls_connection, err =
		tls.Dial(client_connection_type, client_connection_address, tls_config)
	if err != nil {

		log.Println(err) //
		return

	}
	defer tls_connection.Close()

	// Request's Parameters.
	request_uri =
		CLIENT_PROTOCOL + client_connection_address + client_connection_path

	request_str =
		CLIENT_PROTOCOL_METHOD + " " + request_uri + " " +
			CLIENT_PROTOCOL_VERSION_FULL + NL +
			"Host: " + client_connection_host + NL +
			"Accept: text/plain" + NL +
			"Accept-Charset: utf-8" + NL +
			NL

	// Send Data.
	log.Println(NL + request_str) ///
	n, err = tls_connection.Write([]byte(request_str))
	if err != nil {

		log.Println(n, err) //
		return
	}

	// Get Reply.
	for {

		n, err = tls_connection.Read(buffer)
		if err != nil {

			log.Println(n, err) //

			if err == io.EOF {

				// Save Data & Exit.
				data = buffer[:n]
				log.Println("Last Data arrived:" + NL + "---" + NL +
					string(data) + NL + "---") ///
				servers_reply = append(servers_reply, data...)

				break

			} else {

				return
			}
		}

		// Save Data & Proceed.
		data = buffer[:n]
		log.Println("Data arrived:" + NL + "---" + NL +
			string(data) + NL + "---") ///
		servers_reply = append(servers_reply, data...)
	}

	log.Println(string(servers_reply)) ///

}

//------------------------------------------------------------------------------
